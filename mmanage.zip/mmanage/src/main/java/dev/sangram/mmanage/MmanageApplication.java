package dev.sangram.mmanage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MmanageApplication {

	public static void main(String[] args) {
		SpringApplication.run(MmanageApplication.class, args);
	}

}
