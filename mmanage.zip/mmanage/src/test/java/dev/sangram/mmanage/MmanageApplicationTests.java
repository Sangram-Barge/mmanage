package dev.sangram.mmanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmanageApplicationTests {

	@Test
	void contextLoads() {
	}

}
